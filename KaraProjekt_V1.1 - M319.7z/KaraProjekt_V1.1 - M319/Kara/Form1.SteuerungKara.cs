﻿using System.Drawing;
using System.Windows.Forms;

namespace KaraProjekt
{
    //cKara Version 1.1 by Barbara Bielawski
    public partial class Form1 : Form
    {
        private void Main(string args)
        {
            ////Hier die Anweisungen notieren

            ////while (!kara.OnLeaf())
            ////{
            ////    findWall();
            ////    wallright();
            ////}


            //Aufgabe 4.1
            //if (kara.TreeFront())
            //{
            //    GehUmBauHerum();
            //}
            //else { kara.Move(); }



            //Aufgabe 4.2
            //while (!kara.TreeFront())
            //{
            //    if (kara.OnLeaf())
            //    {
            //        kara.RemoveLeaf();
            //    }
            //    else
            //    { 
            //        kara.Move();
            //    }
            //}

            //Aufgabe 4.3 & 4.4

            //while (!kara.OnLeaf())
            //{
            //    if (kara.TreeFront())
            //    {
            //        AvoidTree();
            //    }
            //    else
            //    {
            //        kara.Move();
            //    }
            //}

            //Aufgabe 4.5

            //while (!(kara.TreeRight() & kara.TreeLeft() & kara.TreeFront())) 
            //{
            //    if (kara.TreeFront())
            //    {
            //        ChangeDirection();
            //    }
            //    else
            //    {
            //        kara.Move();
            //    }
            //}

            //Aufgabe 4.6

            //while (true)
            //{
            //    if (!kara.TreeRight())
            //    {
            //        kara.TurnRight();
            //        kara.Move();
            //    }
            //    else if (kara.TreeFront())
            //    {
            //        kara.TurnLeft();
            //    }
            //    else
            //    {
            //        MoveTreeRight();
            //    }
            //}


            //Aufgabe 4.7

            //while (!kara.TreeFront()) 
            //{
            //    if (kara.LeafFront())
            //    {
            //        kara.Move();
            //    }
            //    else
            //    {
            //        SearchLeaf();
            //   }
            //}

            //Aufgabe 4.8

            //bool b = true;
            //while (!(kara.TreeFront() & kara.TreeRight()))
            //{
            //    if (kara.OnLeaf())
            //    {
            //        kara.RemoveLeaf();
            //    }
            //    else
            //    {
            //        kara.PutLeaf();
            //    }

            //    if (kara.TreeFront() && b)
            //    {
            //        BounceRight();
            //        b = false;
            //    }
            //    else if(kara.TreeFront() && !b)
            //    {
            //        BounceLeft();
            //        b = true;
            //    }
            //    else
            //    {
            //        kara.Move();
            //    }
            //}


            //Aufgabe 4.9

            //bool b = true;
            //bool c = false;
            //while (!(kara.TreeFront() & kara.TreeRight()))
            //{
            //    if (c)
            //    {
            //        kara.PutLeaf();
            //        c = false;

            //    }
            //    else
            //    {
            //        c = true;
            //    }

            //    if (kara.TreeFront() && b)
            //    {
            //        BounceRight();
            //        b = false;
            //    }
            //    else if (kara.TreeFront() && !b)
            //    {
            //        BounceLeft();
            //        b = true;
            //    }
            //    else
            //    {
            //        kara.Move();
            //    }
            //}

            //Aufgabe 4.x
            //bool b = false;
            //int width = 8;
            //int height = 8;
            //for(int i = 0; i < width; i++)
            //{
            //    for(int j = 0; j < height; j++)
            //    {
            //        kara.PutLeaf();
            //        kara.Move();

            //    }
            //    if (!b)
            //    {
            //        kara.TurnRight();
            //        kara.Move();
            //        kara.TurnRight();
            //        kara.Move();

            //        b = true;
            //    }
            //    else
            //    {
            //        kara.TurnLeft();
            //        kara.Move();
            //        kara.TurnLeft();
            //        kara.Move();
            //        b = false;    
            //    }
            //}

            //bool b = true;
            //int width = 8;
            //int height = 11;
            //for (int i = 0; i < width; i++)
            //{
            //    kara.Move();
            //    for (int j = 0; j < height; j++)
            //    {
            //        kara.PutLeaf();
            //        kara.Move();
            //    }

            //    if (!b)
            //    {
            //        kara.TurnRight();
            //        kara.Move();
            //        kara.TurnRight();
            //        kara.Move();

            //        b = true;
            //    }
            //    else
            //    {
            //        kara.TurnLeft();
            //        kara.Move();
            //        kara.TurnLeft();
            //        kara.Move();
            //        b = false;
            //    }

            //    height = height - 2;
            //}

            ////Aufgabe 4.10
            //for (int i = 0; i < 6; i++)
            //{
            //    while (!kara.TreeFront())
            //    {
            //        kara.Move();
            //    }
            //    AvoidTree();
            //}

            ////Aufgabe 4.11

            //while(!kara.TreeLeft())
            //{
            //    if (kara.TreeRight())
            //    {
            //        for(int i = 0; i < 4; i++)
            //        {
            //            kara.PutLeaf();
            //            kara.Move();
            //        }

            //    }
            //    else
            //    {
            //        kara.Move();
            //    }
            //}


            ////Aufgabe 4.12
            //int tree;
            //while (!kara.TreeLeft())
            //{
            //    if (kara.TreeRight())
            //    {
            //        tree = 0;
            //        while (kara.TreeRight())
            //        {
            //            kara.Move();
            //            tree++;
            //        }
            //        kara.TurnLeft();
            //        for (int i = 0; i < tree; i++)
            //        {
            //            kara.PutLeaf();
            //            kara.Move();
            //        }
            //        kara.TurnRight();
            //        kara.TurnRight();
            //        for (int i = 0; i < tree; i++)
            //        {
            //            kara.Move();
            //        }
            //        kara.TurnLeft();
            //    } 
            //    else
            //    {
            //        kara.Move();
            //    }
            //}

            ////Aufgabe 5.2

            //int size = 5;
            //DrawSquare(size);

            ////Aufgabe 5.3
            //
            //int width = 5;
            //int height = 3;

            //DrawRectangle(width,height);


            ////Aufgabe 5.4

            //int size = 5;
            //Pyramid(size);

            ////Aufgabe 5.4

            //int size = 5;
            //Frame(size);

            ////Aufgabe 5.5

            //int width = 5;
            //int height = 7;

            //Frame(width, height);

            //Aufgabe 5.6


            //int size = 7;

            //Funnel(size);
            //Pyramid(size);

            int size = 3;
            Diamond(size);














            //Programmende: nächste Zeile bitte nicht löschen
            MessageBox.Show("Task failed successfully");
        }


        private void AvoidTree()
        {
            kara.TurnLeft();
            kara.Move();
            kara.TurnRight();
            kara.Move();
            kara.Move();
            kara.TurnRight();
            kara.Move();
            kara.TurnLeft();
        }
        private void CircleTree()
        {
            kara.TurnLeft();
            MoveTreeRight();
            kara.TurnRight();
            kara.Move();
            MoveTreeRight();
            kara.TurnRight();
            kara.Move();
            MoveTreeRight();
            kara.TurnRight();
            kara.Move();
            MoveTreeRight();
            kara.Move();
            kara.TurnLeft();
        }

        private void ChangeDirection()
        {
            if (!kara.TreeLeft())
            {
                kara.TurnLeft();
            }
            else if (!kara.TreeRight())
            {
                kara.TurnRight();
            }
            else { }
        }

        private void SearchLeaf()
        {
            {
                if (kara.LeafLeft())
                {
                    kara.TurnLeft();
                }
                else if (kara.LeafRight())
                {
                    kara.TurnRight();
                }
                else { }
            }
        }

        private void MoveTreeRight()
        {
            while (kara.TreeRight())
            {
                kara.Move();
            }
        }

        private void BounceLeft()
        {
            if (!kara.TreeLeft())
            {
                kara.TurnLeft();
                kara.Move();
                kara.TurnLeft();
            }
            else if (kara.TreeLeft() && kara.TreeRight())
            {
                return;
            }
            else
            {
                kara.TurnRight();
                kara.Move();
                kara.TurnRight();
            }

        }
        private void BounceRight()
        {
            if (!kara.TreeRight())
            {
                kara.TurnRight();
                kara.Move();
                kara.TurnRight();
            }
            else if (kara.TreeLeft() && kara.TreeRight())
            {
                return;
            }
            else
            {
                kara.TurnLeft();
                kara.Move();
                kara.TurnLeft();

            }
        }
        private void Truebounce(bool right) //Bounce Right -> true
        {

            if (right)
            {

                BounceRight();
                right = false;

            }
            else
            {
                BounceLeft();
                right = true;
            }
        }
        private void PassTree()
        {
            kara.TurnLeft();
            MoveTreeRight();
            kara.TurnRight();
            kara.Move();
            MoveTreeRight();
            kara.TurnRight();
            kara.Move();
            kara.TurnLeft();
        }
        //Aufgabe 4.1
        private void GehUmBauHerum()
        {
            kara.TurnLeft();
            kara.Move();
            kara.TurnRight();
            kara.Move();
            kara.Move();
            kara.TurnRight();
            kara.Move();
            kara.TurnLeft();
        }
        private void Turn180()
        {
            kara.TurnLeft();
            kara.TurnLeft();
        }

        // Mit Parameter
        private void PutX(int size)
        {
            for (int i = 0; i < size; i++)
            {
                kara.PutLeaf();
                kara.Move();
            }
        }

        private void PutXN(int size)
        {
            for (int i = 0; i < size; i++)
            {
                kara.Move();
                kara.PutLeaf();
            }
        }
        void MoveX(int anzahl)
        {
            for (int i = 0; i < anzahl; i++)
            {
                kara.Move();
            }
        }
        private void DrawSquare(int i)
        {
            bool x = false;
            for (int j = 0; j < i; j++)
            {

                PutX(i);
                if (x)
                {

                    BounceRight();
                    x = false;

                }
                else
                {
                    BounceLeft();
                    x = true;
                }

                kara.Move();
            }
        }
        private void DrawRectangle(int width, int height)
        {

            bool x = false;
            for (int j = 0; j < width; j++)
            {

                PutX(height);
                if (x)
                {

                    BounceRight();
                    x = false;

                }
                else
                {
                    BounceLeft();
                    x = true;
                }

                kara.Move();
            }
        }
        private void Pyramid(int size)
        {
            int modulo = size % 2;
            int higth = (size / 2) + modulo;

            bool right = false;
            for (int i = 0; i < higth; i++)
            {
                PutX(size);
                Truebounce(right);
                kara.Move();
                if (i != (higth - 1))
                {
                    kara.Move();
                }
                size -= 2;
                if (right)
                {
                    right = false;
                }
                else
                {
                    right = true;
                }
            }
        }
        private void Frame(int width, int height)
        {
            PutXN(width);
            kara.TurnRight();
            PutXN(height - 2);
            kara.TurnRight();
            PutXN(width);
            kara.TurnRight();
            PutXN(height - 2);

        }
        private void Funnel(int size)
        {

            int modulo = size % 2;
            int higth = (size / 2) + modulo - 1;
            int funnelsize = size - (higth * 2);
            bool right = true;

            for (int i = 0; i < higth; i++)
            {
                PutX(funnelsize);
                funnelsize += 2;
                Truebounce(right);
                if (right)
                {
                    right = false;
                }
                else
                {
                    right = true;
                }
            }

        }

        private void PutConeRow(int size)
        {
            for (int i= 0; i < size; i++)
            {
                kara.PutLeaf();
                kara.Move();
                kara.TurnRight();
                kara.Move();
                kara.TurnLeft();
            }
        }
        private void Diamond(int size)
        {
            bool right = false;

            for (int i = 0; i < (size + 1 * 2) ; i++)
            {
                PutConeRow(size);
                Truebounce(right);
                if (right)
                {
                    kara.Move();
                    kara.TurnRight();
                    kara.Move();
                    kara.TurnLeft();
                    size++;

                    right = false;
                }
                else
                {
                    size--;
                    right = true;
                }
            }
        }
    }
}

